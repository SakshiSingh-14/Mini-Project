<?php 
$con = mysqli_connect('localhost', 'root', 'Rootroot', 'wms');
?>